# GO GO Delivery Partner — Android प्रोजेक्ट

हा Android Studio साठी तयार केलेला **MVP UI prototype** आहे. यात Login screen (demo OTP), Home dashboard, online/offline switch, sample orders, order details, accept order, delivery progress, demo earnings आणि profile screens आहेत.

## Android Studio मध्ये उघडणे
1. ZIP extract करा.
2. Android Studio → **Open** → `GO_GO_Delivery_Partner` फोल्डर निवडा.
3. Gradle Sync पूर्ण होऊ द्या (इंटरनेट आवश्यक).
4. Android फोनमध्ये Developer options → USB debugging सुरू करून फोन जोडावा, किंवा Emulator निवडावा.
5. Run ▶ दाबा. APK साठी **Build → Build APK(s)** निवडा.

APK साधारणपणे `app/build/outputs/apk/debug/app-debug.apk` येथे तयार होईल.

## महत्त्वाच्या मर्यादा
- हा सध्या demo/MVP आहे; खरा OTP/SMS, server/database, real-time order dispatch, GPS tracking/maps, payment collection, bank payout, KYC document upload आणि admin panel जोडलेले नाहीत.
- स्क्रीनमधील sample orders फक्त UI तपासण्यासाठी आहेत; ते खरे ग्राहक ऑर्डर नाहीत.
- फोन नंबर व कोणतेही 4 OTP digits टाकून demo login करता येतो. हा सुरक्षित production authentication नाही.
- Live delivery व्यवसायासाठी वापरण्यापूर्वी backend, privacy/security, permissions, OTP provider, maps, payment आणि admin system जोडणे आवश्यक आहे.

## Package
`com.gogo.partner` | Version `1.0.0` | Minimum Android 7.0 (API 24)
