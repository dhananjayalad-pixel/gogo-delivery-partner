package com.gogo.partner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF10233F)
private val Orange = Color(0xFFFF7A1A)
private val Pale = Color(0xFFF4F6FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoGoTheme { GoGoApp() } }
    }
}

@Composable
private fun GoGoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Orange, background = Pale, surface = Color.White), content = content)
}

private data class DeliveryOrder(val code: String, val shop: String, val pickup: String, val customer: String, val drop: String, val km: String, val pay: Int, val mode: String)
private val demoOrders = listOf(
    DeliveryOrder("GO-8841", "Fresh Bake House", "College Road, Nashik", "Pooja", "Gangapur Road, Nashik", "4.2 km", 85, "ONLINE"),
    DeliveryOrder("GO-8842", "City Electronics", "Nashik Road", "Amit", "Dwarka, Nashik", "5.6 km", 110, "CASH"),
    DeliveryOrder("GO-8843", "Daily Needs Store", "Panchavati, Nashik", "Sneha", "Canada Corner, Nashik", "3.1 km", 72, "ONLINE")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoGoApp() {
    var loggedIn by remember { mutableStateOf(false) }
    var phone by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var online by remember { mutableStateOf(false) }
    var active by remember { mutableStateOf<DeliveryOrder?>(null) }
    var stage by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<DeliveryOrder?>(null) }
    var orders by remember { mutableStateOf(demoOrders) }
    var today by remember { mutableIntStateOf(0) }

    if (!loggedIn) {
        LoginScreen(phone, { phone = it }, otp, { otp = it }, { loggedIn = true })
        return
    }
    Scaffold(
        containerColor = Pale,
        topBar = { TopAppBar(title = { Column { Text("GO GO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp); Text("DELIVERY PARTNER", color = Color.White.copy(alpha=.8f), fontSize = 10.sp, letterSpacing = 2.sp) } }, actions = { IconButton(onClick = {}) { Icon(Icons.Default.Notifications, null, tint = Color.White) } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)) },
        bottomBar = { NavigationBar(containerColor = Color.White) {
            listOf("Home", "Orders", "Earnings", "Profile").forEachIndexed { i, label ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i; selected = null }, icon = { Icon(listOf(Icons.Default.Home, Icons.Default.Inventory2, Icons.Default.AccountBalanceWallet, Icons.Default.Person)[i], null) }, label = { Text(label) })
            }
        } }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when {
                selected != null -> OrderDetail(selected!!, onBack = { selected = null }, onAccept = { active = selected; stage = 0; orders = orders.filterNot { it.code == selected!!.code }; selected = null; tab = 0 })
                active != null -> ActiveDelivery(active!!, stage, onNext = { if (stage < 6) stage++ else { today += active!!.pay; active = null; stage = 0 } }, onBack = { active = null })
                tab == 0 -> HomeScreen(online, { online = it }, orders.size, today, onOrders = { tab = 1 }, onEarnings = { tab = 2 })
                tab == 1 -> OrdersScreen(orders, online, onSelect = { selected = it }, onOnline = { online = it })
                tab == 2 -> EarningsScreen(today)
                else -> ProfileScreen(phone, onLogout = { loggedIn = false; tab = 0 })
            }
        }
    }
}

@Composable
private fun LoginScreen(phone: String, onPhone: (String) -> Unit, otp: String, onOtp: (String) -> Unit, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Navy).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("GO GO", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black)
        Text("DELIVERY PARTNER", color = Orange, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Spacer(Modifier.height(38.dp)); Text("Welcome, Partner!", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Sign in to start your delivery journey", color = Color.LightGray)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(value = phone, onValueChange = onPhone, label = { Text("Mobile number") }, leadingIcon = { Text("+91") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedLabelColor = Orange, unfocusedLabelColor = Color.LightGray, focusedBorderColor = Orange, unfocusedBorderColor = Color.Gray))
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = otp, onValueChange = onOtp, label = { Text("Demo OTP (enter any 4 digits)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedLabelColor = Orange, unfocusedLabelColor = Color.LightGray, focusedBorderColor = Orange, unfocusedBorderColor = Color.Gray))
        Spacer(Modifier.height(20.dp)); Button(onClick = onContinue, enabled = phone.length >= 10 && otp.length >= 4, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange), shape = RoundedCornerShape(14.dp)) { Text("CONTINUE", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(14.dp)); Text("Prototype login: no real SMS/OTP is connected.", color = Color.LightGray, fontSize = 12.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(online: Boolean, onOnline: (Boolean) -> Unit, count: Int, today: Int, onOrders: () -> Unit, onEarnings: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(20.dp)) { Text("Hello, Delivery Partner 👋", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold); Text("Ready to earn today?", color = Color.LightGray); Spacer(Modifier.height(18.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(if (online) "YOU ARE ONLINE" else "YOU ARE OFFLINE", color = if (online) Color(0xFF7FE0A1) else Color.White, fontWeight = FontWeight.Bold); Text(if (online) "You can receive orders" else "Go online to receive orders", color = Color.LightGray, fontSize = 12.sp) }; Switch(checked = online, onCheckedChange = onOnline) } } } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { StatCard("Today's earning", "₹$today", Icons.Default.CurrencyRupee, Modifier.weight(1f)); StatCard("Available orders", "$count", Icons.Default.Inventory2, Modifier.weight(1f)) } }
        item { Button(onClick = onOrders, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text("VIEW AVAILABLE ORDERS", fontWeight = FontWeight.Bold) } }
        item { Card { Column(Modifier.padding(16.dp)) { Text("Quick actions", fontWeight = FontWeight.Bold, fontSize = 18.sp); TextButton(onClick = onEarnings) { Icon(Icons.Default.AccountBalanceWallet, null); Spacer(Modifier.width(8.dp)); Text("View earnings and payout summary") } } } }
        item { Text("Note: Demo orders are sample data for testing the app screens.", color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) { Card(modifier, shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Icon(icon, null, tint = Orange); Spacer(Modifier.height(8.dp)); Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy); Text(title, color = Color.Gray, fontSize = 12.sp) } } }

@Composable
private fun OrdersScreen(orders: List<DeliveryOrder>, online: Boolean, onSelect: (DeliveryOrder) -> Unit, onOnline: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Available orders", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
        Row(verticalAlignment = Alignment.CenterVertically) { Text(if (online) "Online — receiving orders" else "Offline — go online to receive orders", modifier = Modifier.weight(1f), color = Color.Gray, fontSize = 12.sp); Switch(checked = online, onCheckedChange = onOnline) }
        if (!online) Text("Turn on Online status to start accepting orders.", color = Orange, modifier = Modifier.padding(vertical = 10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) { items(orders) { order -> Card(onClick = { onSelect(order) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp)) { Row { Text(order.code, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.weight(1f)); Text("₹${order.pay}", color = Orange, fontWeight = FontWeight.Bold) }; Text(order.shop, fontWeight = FontWeight.SemiBold); Text("Pickup: ${order.pickup}", color = Color.Gray, fontSize = 13.sp); Text("Drop: ${order.drop} • ${order.km}", color = Color.Gray, fontSize = 13.sp); Spacer(Modifier.height(8.dp)); Row(verticalAlignment = Alignment.CenterVertically) { AssistChip(onClick = {}, label = { Text(order.mode) }); Spacer(Modifier.weight(1f)); Text("VIEW DETAILS →", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp) } } } } }
    }
}

@Composable
private fun OrderDetail(order: DeliveryOrder, onBack: () -> Unit, onAccept: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("← Back to orders") }; Text("Order details", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
        Card { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { Text(order.code, color = Orange, fontWeight = FontWeight.Bold); Text(order.shop, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("PICKUP", color = Color.Gray, fontSize = 11.sp); Text(order.pickup); Divider(); Text("DELIVER TO", color = Color.Gray, fontSize = 11.sp); Text(order.customer); Text(order.drop); Divider(); Row { Text("Distance: ${order.km}", modifier = Modifier.weight(1f)); Text("Payment: ${order.mode}") }; Text("Your earning", color = Color.Gray); Text("₹${order.pay}", fontSize = 28.sp, color = Orange, fontWeight = FontWeight.Bold) } }
        Spacer(Modifier.weight(1f)); Button(onClick = onAccept, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text("ACCEPT ORDER", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun ActiveDelivery(order: DeliveryOrder, stage: Int, onNext: () -> Unit, onBack: () -> Unit) {
    val stages = listOf("Order accepted", "Go to pickup", "Reached pickup", "Parcel picked up", "Go to customer", "Reached customer", "Delivered successfully")
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }; Text("Active delivery", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy); Spacer(Modifier.height(14.dp))
        Card { Column(Modifier.padding(18.dp)) { Text(order.code, color = Orange, fontWeight = FontWeight.Bold); Text(order.shop, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("Deliver to ${order.customer}"); Text(order.drop, color = Color.Gray) } }
        Spacer(Modifier.height(18.dp)); Text("DELIVERY PROGRESS", color = Color.Gray, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        stages.forEachIndexed { i, label -> Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) { Icon(if (i <= stage) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null, tint = if (i <= stage) Orange else Color.LightGray); Spacer(Modifier.width(12.dp)); Text(label, fontWeight = if (i == stage) FontWeight.Bold else FontWeight.Normal, color = if (i <= stage) Navy else Color.Gray) } }
        Spacer(Modifier.weight(1f)); Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text(if (stage == 6) "COMPLETE DELIVERY" else "NEXT STEP", fontWeight = FontWeight.Bold) }
        Text("Demo workflow only — OTP verification and live tracking are not connected.", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
private fun EarningsScreen(today: Int) { LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { item { Text("My earnings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy) }; item { Card(colors = CardDefaults.cardColors(containerColor = Navy)) { Column(Modifier.padding(22.dp)) { Text("TODAY'S EARNINGS", color = Color.LightGray); Text("₹$today", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold); Text("Demo earnings from completed sample deliveries", color = Color.LightGray, fontSize = 12.sp) } } }; item { Card { Column(Modifier.padding(18.dp)) { Text("Payout account", fontWeight = FontWeight.Bold); Text("Bank details will appear after partner KYC is connected.", color = Color.Gray, fontSize = 13.sp) } } } } }

@Composable
private fun ProfileScreen(phone: String, onLogout: () -> Unit) { Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { Text("My profile", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy); Card { Column(Modifier.padding(18.dp)) { Icon(Icons.Default.AccountCircle, null, tint = Orange, modifier = Modifier.size(54.dp)); Text("GO GO Delivery Partner", fontSize = 19.sp, fontWeight = FontWeight.Bold); Text("Mobile: $phone", color = Color.Gray); Divider(Modifier.padding(vertical = 12.dp)); Text("Registration & KYC", fontWeight = FontWeight.Bold); Text("Personal details • Vehicle details • Identity documents • Bank details", color = Color.Gray, fontSize = 13.sp) } }; Card { Column(Modifier.padding(18.dp)) { Text("Help & support", fontWeight = FontWeight.Bold); Text("Support contact will be configured by the app administrator.", color = Color.Gray, fontSize = 13.sp) } }; Spacer(Modifier.weight(1f)); OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Logout, null); Spacer(Modifier.width(8.dp)); Text("LOG OUT") } } }
